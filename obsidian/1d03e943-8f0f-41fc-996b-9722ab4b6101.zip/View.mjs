// src/View.tsx
import React from "react";
var View_default = () => {
  return /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("h1", null, "Hello, React with Rollup and TypeScript!"));
};
export {
  View_default as default
};
